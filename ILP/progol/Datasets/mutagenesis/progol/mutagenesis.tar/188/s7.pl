active(d13).
active(d24).
active(d43).
active(d64).
active(d72).
active(d79).
active(d90).
active(d122).
active(d126).
active(d163).
active(d172).
active(d30).
active(d37).
:- active(d2).
:- active(d17).
:- active(d120).
:- active(d130).
:- active(d131).
:- active(d129).
