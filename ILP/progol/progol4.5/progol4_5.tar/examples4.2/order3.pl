% Qualitative regression. Regression here is for polynomial function.
% The underlying function is
%
%	y=2^x+1

:- [order]?

f(3.0,9.0).
f(4.0,17.0).
f(9.0,513.0).
f(8.0,257.0).
f(7.0,129.0).
f(6.0,65.0).
f(5.0,33.0).
f(2.0,5.0).
f(1.0,3.0).
