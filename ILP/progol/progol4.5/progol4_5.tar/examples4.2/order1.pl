% Qualitative regression using logs. Regression here is for linear function.
% The underlying function is
%
%	y=3x+11

:- [order]?

f(15.0,56.0).
f(1.0,14.0).
f(2.0,17.0).
f(3.0,20.0).
f(4.0,23.0).
f(5.0,26.0).
f(6.0,29.0).
f(7.0,32.0).
f(8.0,35.0).
f(9.0,38.0).
f(10.0,41.0).
f(11.0,44.0).
f(12.0,47.0).
f(13.0,50.0).
f(14.0,53.0).
