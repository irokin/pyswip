name(aleph).
title('Aleph Inductive Logic Programming system').
version('5').
author('Fabrizio Riguzzi', 'fabrizio.riguzzi@unife.it').
